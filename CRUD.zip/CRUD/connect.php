<?php
$con=mysqli_connect("localhost","root","","crud");
if(!$con){
    die("Cannot connect with database");
}
?>